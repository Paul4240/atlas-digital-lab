import Nav from "../../components/Nav";
import Footer from "../../components/Footer";

export default function Contact() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-3xl mx-auto">
        <h1 className="text-4xl font-semibold mb-6">Contact</h1>
        <p className="text-neutral-400 mb-10">
          Tell us a bit about your business and we’ll respond within 24 hours.
        </p>

        <form
          action="https://formspree.io/f/YOUR_FORM_ID"
          method="POST"
          className="space-y-6"
        >
          <input
            name="name"
            placeholder="Name"
            required
            className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg"
          />
          <input
            name="email"
            type="email"
            placeholder="Email"
            required
            className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg"
          />
          <input
            name="business"
            placeholder="Business Name"
            required
            className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg"
          />
          <input
            name="phone"
            placeholder="Phone"
            className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg"
          />
          <textarea
            name="message"
            placeholder="Message"
            required
            className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg h-32"
          />
          <button className="bg-white text-black px-6 py-3 rounded-full font-medium">
            Send Message
          </button>
        </form>

        <p className="text-neutral-400 mt-10">
          Or email: <span className="text-white">hello@atlasstudio.com</span>
        </p>
      </section>

      <Footer />
    </main>
  );
}
