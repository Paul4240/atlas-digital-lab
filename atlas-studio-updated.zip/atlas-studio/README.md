# Atlas Studio — Next.js Website

This is a complete Next.js (App Router) project for Atlas Studio.

## Features
- Home, Services, Pricing, About, Contact pages
- Tailwind CSS styling
- Contact form ready for Formspree

## Setup
1. Install dependencies
   ```bash
   npm install
   ```

2. Run locally
   ```bash
   npm run dev
   ```

## Contact Form
Replace the Formspree action URL in:

`app/contact/page.tsx`

```tsx
action="https://formspree.io/f/YOUR_FORM_ID"
```

---

## Deploy
You can deploy this to Vercel in minutes.


## Domain & Hosting

- **Domain chosen:** AtlasWebLab.com
- **Hosting:** Vercel (recommended for Next.js)

## Pricing Update

- Starter Website price updated to **$500**.

## New Pages

- `/portfolio` (sample portfolio placeholders)
- `/intake` (client intake form)
