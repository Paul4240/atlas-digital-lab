import Link from "next/link";
import Nav from "../components/Nav";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-6xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-semibold leading-tight">
          Professional websites for local businesses — built properly.
        </h1>
        <p className="mt-6 text-lg md:text-xl text-neutral-400 max-w-2xl">
          We design and build clean, modern websites that help local businesses look credible,
          get more calls, and grow with confidence.
        </p>
        <Link
          href="/contact"
          className="inline-block mt-10 bg-white text-black px-8 py-4 rounded-full font-medium shadow-sm hover:shadow-lg transition"
        >
          Request a Website
        </Link>
      </section>

      <section className="px-6 py-16 bg-atlas-900">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          <Feature title="Professional Design" desc="Clean, modern websites built to reflect your business." />
          <Feature title="Mobile Ready" desc="Optimized for phones, tablets, and desktops." />
          <Feature title="Fast Turnaround" desc="Most sites launched in 7 days." />
        </div>
      </section>

      <section className="px-6 py-20 max-w-6xl mx-auto">
        <div className="rounded-2xl border border-atlas-border p-10">
          <h2 className="text-3xl font-semibold">Ready to upgrade your website?</h2>
          <p className="text-neutral-400 mt-4 max-w-2xl">
            If you want a professional site that brings in more calls, we’re ready to help.
          </p>
          <Link
            href="/contact"
            className="inline-block mt-8 bg-white text-black px-8 py-4 rounded-full font-medium shadow-sm hover:shadow-lg transition"
          >
            Request a Website
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}

function Feature({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="border border-atlas-border p-8 rounded-2xl">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-neutral-400">{desc}</p>
    </div>
  );
}
