import Link from "next/link";
import Nav from "../../components/Nav";
import Footer from "../../components/Footer";

export default function Services() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-6xl mx-auto">
        <h1 className="text-4xl font-semibold mb-6">Services</h1>
        <p className="text-neutral-400 mb-10">
          We design and build professional websites for local service businesses.
          Everything is handled for you — clean design, mobile-ready, and launched on time.
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          <Card title="Website Design & Build" desc="Custom website design, mobile-ready, built for trust and conversions." />
          <Card title="Contact Form" desc="A simple contact form that delivers messages directly to you." />
          <Card title="Basic SEO Setup" desc="On-page SEO basics so your business can be found online." />
        </div>

        <div className="mt-12">
          <Link
            href="/contact"
            className="bg-white text-black px-8 py-4 rounded-full font-medium shadow-sm hover:shadow-lg transition"
          >
            Request a Website
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}

function Card({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="border border-atlas-border p-8 rounded-2xl">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-neutral-400">{desc}</p>
    </div>
  );
}
