import Link from "next/link";
import Nav from "../../components/Nav";
import Footer from "../../components/Footer";

export default function Pricing() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-6xl mx-auto">
        <h1 className="text-4xl font-semibold mb-6">Pricing</h1>
        <p className="text-neutral-400 mb-10">
          Simple, transparent pricing. No confusing packages.
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="border border-atlas-border p-8 rounded-2xl">
            <h3 className="text-xl font-semibold mb-2">Starter Website</h3>
            <p className="text-3xl font-bold mb-4">$500</p>
            <p className="text-neutral-400">
              1–3 pages, mobile-friendly, contact form, basic SEO setup, launched in ~7 days.
            </p>
          </div>
        </div>

        <div className="mt-12">
          <Link
            href="/contact"
            className="bg-white text-black px-8 py-4 rounded-full font-medium shadow-sm hover:shadow-lg transition"
          >
            Request a Website
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}
