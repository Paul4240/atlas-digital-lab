import Nav from "../../components/Nav";
import Footer from "../../components/Footer";

export default function Intake() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-4xl mx-auto">
        <h1 className="text-4xl font-semibold mb-6">Client Intake Form</h1>
        <p className="text-neutral-400 mb-10">
          This form helps us understand your business and build the right website for you.
          If you prefer, you can also send this information via email.
        </p>

        <form className="space-y-6">
          <Input label="Full Name" name="name" required />
          <Input label="Email" name="email" type="email" required />
          <Input label="Phone" name="phone" type="tel" />
          <Input label="Business Name" name="business" required />
          <Input label="Industry / Service" name="industry" required />
          <Input label="Website URL (if you have one)" name="website" />
          <Textarea label="What do you want your website to accomplish?" name="goals" required />
          <Textarea label="What pages do you need?" name="pages" placeholder="Example: Home, Services, About, Contact, Pricing" />
          <Input label="Budget (approx.)" name="budget" placeholder="Example: $500" />
          <Input label="Desired Launch Date" name="launch" type="date" />
          <Textarea label="Any notes or special requests?" name="notes" />
          <button
            type="submit"
            className="bg-white text-black px-6 py-3 rounded-full font-medium"
          >
            Submit
          </button>
        </form>

        <p className="text-neutral-400 mt-10">
          This form is currently for internal use. When you are ready, we can connect it to an email or CRM.
        </p>
      </section>

      <Footer />
    </main>
  );
}

function Input({ label, name, type = "text", required = false, placeholder }: { label: string; name: string; type?: string; required?: boolean; placeholder?: string }) {
  return (
    <div>
      <label className="block text-neutral-300 mb-2">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg"
      />
    </div>
  );
}

function Textarea({ label, name, required = false, placeholder }: { label: string; name: string; required?: boolean; placeholder?: string }) {
  return (
    <div>
      <label className="block text-neutral-300 mb-2">{label}</label>
      <textarea
        name={name}
        required={required}
        placeholder={placeholder}
        className="w-full bg-atlas-900 border border-atlas-border px-4 py-3 rounded-lg h-32"
      />
    </div>
  );
}
