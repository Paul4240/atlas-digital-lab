/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        atlas: {
          950: "#070A0F",
          900: "#0B0F16",
          850: "#0E1320",
        }
      }
    },
  },
  plugins: [],
}
