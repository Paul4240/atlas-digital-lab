import Link from "next/link";
import Nav from "../../components/Nav";
import Footer from "../../components/Footer";

export default function About() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-6xl mx-auto">
        <h1 className="text-4xl font-semibold mb-6">About</h1>

        <p className="text-neutral-400 mb-6">
          Atlas Studio builds professional websites for local service businesses that want a clean,
          modern online presence without the stress.
        </p>

        <h2 className="text-2xl font-semibold mb-3">Who We Work With</h2>
        <p className="text-neutral-400 mb-6">
          Plumbers, electricians, landscapers, cleaning services, contractors — any local business that
          wants a website that looks professional and works.
        </p>

        <h2 className="text-2xl font-semibold mb-3">Our Approach</h2>
        <p className="text-neutral-400 mb-6">
          You provide your business details, we build the website, you review and approve, then we launch.
          Simple and efficient.
        </p>

        <Link
          href="/contact"
          className="bg-white text-black px-8 py-4 rounded-full font-medium shadow-sm hover:shadow-lg transition"
        >
          Request a Website
        </Link>
      </section>

      <Footer />
    </main>
  );
}
