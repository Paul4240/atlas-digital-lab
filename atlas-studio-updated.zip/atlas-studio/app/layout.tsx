import "./globals.css";

export const metadata = {
  title: "Atlas Studio",
  description: "Luxury websites for local businesses",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-atlas-950">
        {children}
      </body>
    </html>
  );
}
