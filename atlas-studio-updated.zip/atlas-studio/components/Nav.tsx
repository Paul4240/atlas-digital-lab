import Link from "next/link";

export default function Nav() {
  return (
    <nav className="flex items-center justify-between px-6 py-6 border-b border-atlas-border">
      <Link href="/" className="text-xl font-semibold tracking-wide">
        Atlas Studio
      </Link>
      <div className="flex gap-6 text-neutral-300">
        <Link href="/">Home</Link>
        <Link href="/services">Services</Link>
        <Link href="/pricing">Pricing</Link>
        <Link href="/about">About</Link>
        <Link href="/portfolio">Portfolio</Link>
        <Link href="/intake">Intake</Link>
        <Link href="/contact">Contact</Link>
      </div>
    </nav>
  );
}
