import Link from "next/link";
import Nav from "../../components/Nav";
import Footer from "../../components/Footer";

export default function Portfolio() {
  return (
    <main className="min-h-screen">
      <Nav />

      <section className="px-6 py-20 max-w-6xl mx-auto">
        <h1 className="text-4xl font-semibold mb-6">Portfolio</h1>
        <p className="text-neutral-400 mb-10">
          Atlas Studio is new and currently building its first projects.
          In the meantime, here are <span className="text-white font-medium">sample layouts</span> that reflect the style and quality you can expect.
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          <WorkCard
            title="Local Service Landing Page"
            desc="Clean hero, clear services, and a strong call-to-action designed to generate calls."
          />
          <WorkCard
            title="Small Business Website"
            desc="Simple multi-page site with an About page, Pricing, and Contact form."
          />
          <WorkCard
            title="Single-Page Conversion Site"
            desc="Focused on one offer, with a streamlined structure and fast load speed."
          />
          <WorkCard
            title="Appointment-Based Site"
            desc="Designed for scheduling, with clear contact details and trust signals."
          />
        </div>

        <div className="mt-12 border border-atlas-border rounded-2xl p-8">
          <h2 className="text-2xl font-semibold mb-3">Want to see a custom portfolio for your industry?</h2>
          <p className="text-neutral-400">
            When you request a website, we can show you a mockup tailored to your business before you pay.
          </p>
          <Link href="/contact" className="inline-block mt-6 bg-white text-black px-8 py-4 rounded-full font-medium">
            Request a Website
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}

function WorkCard({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="border border-atlas-border p-8 rounded-2xl">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-neutral-400">{desc}</p>
      <div className="mt-6 h-40 bg-atlas-900 border border-atlas-border rounded-lg flex items-center justify-center text-neutral-500">
        Sample preview
      </div>
    </div>
  );
}
